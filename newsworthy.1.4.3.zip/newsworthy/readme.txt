﻿================
NEWSWORTHY THEME
================
Copyright (c) 2012 by WPThemes NZ (http://wpthemes.co.nz/)
Newsworthy Theme is distributed under the terms of the GNU GPL.

===========
ABOUT Theme
===========
Newsworthy theme is a simple theme with cool design and beautiful color accents. It's a fun and functional theme perfect for the personal blogger. Featuring a traditional layout it supports custom menus and is widget ready.

This theme is compatible with Wordpress Version 3.4 and above and it supports the new custom background feature (https://codex.wordpress.org/Custom_Backgrounds).

All the image graphics and icons bundled with this theme are created by the author and licensed under the GPL.

Google webfont used is 'Oswald'.

For free themes support, please contact us http://wpthemes.co.nz/contact/

============================================
This theme uses Toolbox as a theme framework
============================================
 * Toolbox (http://wordpress.org/extend/themes/toolbox)
 * Copyright (c) Automattic (http://automattic.com)
 * Available under the terms of GNU GPL.


======================================
This theme uses Bones as a design tool
======================================
 * Bones (http://themble.com/bones)
 * Copyright (c) Eddie Machado (http://eddiemachado.com/)
 * This is totally free and under WTFPL license (Please read http://themble.com/bones/ for more information)


=====================================
This theme is bundled with Modernizr 
=====================================
 * Modernizr v2.6.1 (www.modernizr.com)
 * Modernizr is a JavaScript library that detects HTML5 and CSS3 features in the user’s browser.
 * Copyright (c) Faruk Ates, Paul Irish, Alex Sexton
 * Available under the BSD and MIT licenses: www.modernizr.com/license/


===============
Version History
===============
Version 1.4.3
 * fixed the nav sub-menu bug that happens whenever you hover over level one you see both level 2 and level 3 appear
 * updated readme to include all version changes and removed changelog.txt
 
Version 1.4.2
 * minor css fixes and footer updates
 
Version 1.4.1
 * fixed the seo-seeded footer link anchor text

Version 1.4
 * replaced get_template_directory_uri() with get_stylesheet_uri() to enqueue stylesheet in functions.php
 * updated the footer credit

Version 1.3
 * Fixed License and License URI header slugs in style.css
 * Fixed: Widget is not Showing behind the content area

Version 1.2
 * Fixed copyright and license information.

Version 1.1
 * Enqueued style.css
 * Fixed <?php get_search_form(); ?> appearing twice in header.php
 * Fixed site description overlapping with the search box
 * Added custom background support (Wordpress 3.4)
 * Updated gallery thumbnail styles
 * Updated 404 page
 * Updated readme
 * Added Modernizr script
 
 Version 1.0
 * Hello World!