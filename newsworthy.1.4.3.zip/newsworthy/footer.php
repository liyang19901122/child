
	<footer id="colophon" role="contentinfo">
		<div id="site-generator">
			<?php echo __('&copy; ', 'newsworthy') . esc_attr( get_bloginfo( 'name', 'display' ) );  ?>
            <?php if ( is_front_page() && ! is_paged() ) : ?>
            <?php _e('- Powered by ', 'newsworthy'); ?><a href="<?php echo esc_url( __( 'http://wordpress.org/', 'newsworthy' ) ); ?>" title="<?php esc_attr_e( 'Semantic Personal Publishing Platform', 'newsworthy' ); ?>"><?php _e('Wordpress' ,'newsworthy'); ?></a>
			<?php _e(' and ', 'newsworthy'); ?><a href="<?php echo esc_url( __( 'http://wpthemes.co.nz/', 'newsworthy' ) ); ?>"><?php _e('WPThemes.co.nz', 'newsworthy'); ?></a>
            <?php endif; ?>
		</div>
	</footer><!-- #colophon -->
</div><!-- #container -->

<?php wp_footer(); ?>

</body>
</html>